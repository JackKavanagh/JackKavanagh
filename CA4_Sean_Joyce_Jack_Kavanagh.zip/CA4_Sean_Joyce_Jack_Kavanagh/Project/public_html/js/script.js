//Setup for localstorage varibles to pass data to another page
function setLocalStorage() {
    localStorage.total = 0;
    localStorage.orders = "";
    localStorage.quantity = "";
    localStorage.name = "";
    localStorage.surname = "";
    localStorage.address = "";
}

//main function to run when adding and saving the order
function main() {
    var productName = ["BenQ", "Acer", "Gtx970", "Gtx760", "Raspberry Pi B", "Raspberry Pi 2"];
    var productPrice = [150, 90, 300, 220, 50, 60];
    var quantity = document.getElementById('getQuantity').value;
    var order = searchProducts(productName);

    if (quantity > 0) {
        saveOrder(order, quantity);
        addToTable(productName[order], quantity, productPrice[order], "order");
        calculateTotal(productPrice[order], quantity);

        displayTotal();
    } else {
        alert("Enter quantity above 0");
    }

}

//search the selected product and returns position of item in the array
function searchProducts(array) {
    var selected = document.getElementById('listItems');
    var input = selected.options[selected.selectedIndex].text;
    var i = 0;
    var pos = -1;
    var product = 0;

    while (i < array.length && pos === -1) {
        if (input === array[i]) {
            product = i;
        }
        i++;
    }
    return product;
}

//fills out second selection box when catogary is selected
function selectionList() {
    document.getElementById('listItems').innerHTML = "";
    var productId = ["m01", "m02", "g01", "g02", "r01", "r02"];
    var productName = ["BenQ", "Acer", "Gtx970", "Gtx760", "Raspberry Pi B", "Raspberry Pi 2"];
    var selected = document.getElementById('getProductType').value;
    var productSelect = document.getElementById('listItems');
    var i = 0;

    while (i < productId.length) {
        var product = productId[i];
        if (selected === product.charAt(0)) {
            var opt = document.createElement('option');
            opt.innerHTML = productName[i];
            opt.value = i;
            productSelect.appendChild(opt);
        }
        i++;
    }
}

//calculates total price of order price and quantity
function calculateTotal(productPrice, quantity) {
    var total = 0;
    total = parseInt(productPrice) * parseInt(quantity);
    total = total + (parseInt(localStorage.total));
    localStorage.total = parseInt(total);
}

//dispalys total on order page
function displayTotal() {
    document.getElementById('displayTotal').innerHTML = "Total: " + localStorage.total;
}

//creates rows in table and adds order data 
function addToTable(name, quantity, price, table) {
    var price = price * quantity;
    var array = [name, quantity, price];
    var item;
    var table = document.getElementById(table);
    var row = document.createElement('tr');
    table.appendChild(row);
    for (var i = 0; i < 3; i++) {
        item = document.createElement('td');
        item.innerHTML = array[i];
        row.appendChild(item);
    }
}

//clears current orders
function clearOrder() {
    var x = document.getElementById("order").rows.length;
    var order = document.getElementById('order');
    while (x > 1) {
        order.deleteRow(x - 1);
        x--;
    }
    displayTotal();
    setLocalStorage();
}

//saves the current order into a string in localstorage to open on another page
function saveOrder(orderNumber, quantity) {
    if (localStorage.orders === "") {
        localStorage.orders = orderNumber;
    } else {
        localStorage.orders += orderNumber;
    }

    if (localStorage.quantity === "") {
        localStorage.quantity = quantity + "-";
    } else {
        localStorage.quantity += quantity + "-";
    }
}

//go to the contact details page
function contactDetails() {
    calculateExtras();
    calculateDiscounts();
    window.location.href = "contactDetails.html";
}

//displays date in nav bar
function displayDate() {
    var date = new Date();
    date = date.getDate() + " - " + (date.getMonth() + 1) + " - " + date.getFullYear();
    document.getElementById('navDate').innerHTML = date;
}

//saves contact details from the details page
function saveContactDetails() {
    localStorage.name = document.getElementById('firstName').value;
    localStorage.surname = document.getElementById('surname').value;
    localStorage.address = document.getElementById('address').value;

}

//adds extras to each item ordered
function calculateExtras() {
    var gift = document.getElementById("getGift").checked;
    var expressDelivery = document.getElementById("getExpress").checked;
    var total = 0;
    var delivery = 5;
    var wrap = 0;
    //gift wrapping
    if (gift === true)
    {
        wrap = 3;
    }
    //delivery options
    if (expressDelivery === true)
    {
        delivery = 10;
    }
    total += delivery + wrap;
    total = total + (parseInt(localStorage.total));
    localStorage.total = parseInt(total);
    localStorage.delivery = parseInt(delivery);
    localStorage.wrap = parseInt(wrap);
    
}

//calculates a discount for the order
function calculateDiscounts() {
    var total = parseInt(localStorage.total);
    var expressDelivery = document.getElementById("getExpress").checked;
    var Delivery = parseInt(localStorage.delivery);
    if (total > 500 && expressDelivery === true) {
        total = total - Delivery;
        Delivery = 0;
    }
    else if (total > 500) {
        total = total - Delivery;
        Delivery = 0;
    }

    if (total > 2000) {
        total *= .9;
    }
    localStorage.delivery = Delivery;
    localStorage.total = parseInt(total);
}