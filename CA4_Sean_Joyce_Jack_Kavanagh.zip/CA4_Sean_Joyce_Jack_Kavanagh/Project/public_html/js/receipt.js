function displayOrder() {
    var productName = ["BenQ", "Acer", "Gtx970", "Gtx760", "Raspberry Pi B", "Raspberry Pi 2"];
    var productPrice = [150, 90, 300, 220, 50, 60];
    var currentOrder = "";
    var currentQuantity = "";
    var order = localStorage.orders;
    var quantity = localStorage.quantity;

    var count = 0;
    var x = quantity.charAt(0);
    var i = 0;

    while (i < order.length) {
        currentOrder = order.charAt(i);
        while (x !== "-") {
            currentQuantity += parseInt(x);
            count++;
            x = quantity.charAt(count);
        }

        addToTable(productName[currentOrder], currentQuantity, productPrice[currentOrder], "reciept");
        i++;
    }
    document.getElementById("final").innerHTML = localStorage.total;
}



function displayDetails() {
    document.getElementById('deliveryDetails').innerHTML += localStorage.name + " " + localStorage.surname;
    document.getElementById('addressDetails').innerHTML =  localStorage.address;
    document.getElementById('deliveryMode').innerHTML =  localStorage.delivery;
    document.getElementById('wrap').innerHTML =  localStorage.wrap;
    
}