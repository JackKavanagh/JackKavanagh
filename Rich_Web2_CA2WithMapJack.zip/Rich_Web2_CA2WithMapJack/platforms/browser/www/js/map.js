var url = window.location.href;
var firstSplit = url.toString().split("lat=")[1];
var lat = firstSplit.toString().split("&")[0];
var lng = firstSplit.toString().split("lng=")[1];
var secondsplit = url.toString().split("title=")[1];
var title = secondsplit.toString().split("&desc=")[0];
var thirdsplit = url.toString().split("&desc=")[1];
var desc = thirdsplit.toString().split("&index")[0];
var id = url.toString().split("index=")[1];

window.localStorage.setItem('lat', lat);
window.localStorage.setItem('lng', lng);

title = title.replace(/%20/g, " ");
desc = desc.replace(/%20/g, " ");
id = parseInt(id);

var imageData = window.localStorage.getItem('imageData');
// var index = window.localStorage.getItem('index');

var array = imageData.toString().split(',');

function initMap() {

    var map = new google.maps.Map(document.getElementById('map'), {
        center: {
            lat: -34.397,
            lng: 150.644
        },
        zoom: 6
    });


    var pos = {
        lat: parseFloat(window.localStorage.getItem('lat')),
        lng: parseFloat(window.localStorage.getItem('lng')),
        enableHighAccuracy: false
    };


    var marker = new google.maps.Marker({
        map: map,
        position: new google.maps.LatLng(pos)

    });



    // infoWindow.setContent(title + '<br>' + desc + '<br><img src="images/landmark.png" width="100" height="100"/>');

    map.setCenter(pos);
    new AutocompleteDirectionsHandler(map);

}

function AutocompleteDirectionsHandler(map) {
    this.map = map;
    this.originPlaceId = null;
    this.destinationPlaceId = null;
    this.travelMode = 'WALKING';
    var originInput = document.getElementById('origin-input');
    var destinationInput = document.getElementById('destination-input');
    var modeSelector = document.getElementById('mode-selector');
    this.directionsService = new google.maps.DirectionsService;
    this.directionsDisplay = new google.maps.DirectionsRenderer;
    this.directionsDisplay.setMap(map);

    var originAutocomplete = new google.maps.places.Autocomplete(
        originInput, {
            placeIdOnly: true
        });
    var destinationAutocomplete = new google.maps.places.Autocomplete(
        destinationInput, {
            placeIdOnly: true
        });

    this.setupClickListener('changemode-walking', 'WALKING');
    this.setupClickListener('changemode-transit', 'TRANSIT');
    this.setupClickListener('changemode-driving', 'DRIVING');

    this.setupPlaceChangedListener(originAutocomplete, 'ORIG');
    this.setupPlaceChangedListener(destinationAutocomplete, 'DEST');

    this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(originInput);
    this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(destinationInput);
    this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(modeSelector);
}

AutocompleteDirectionsHandler.prototype.setupClickListener = function(id, mode) {
    var radioButton = document.getElementById(id);
    var me = this;
    radioButton.addEventListener('click', function() {
        me.travelMode = mode;
        me.route();
    });
};

AutocompleteDirectionsHandler.prototype.setupPlaceChangedListener = function(autocomplete, mode) {
    var me = this;
    autocomplete.bindTo('bounds', this.map);
    autocomplete.addListener('place_changed', function() {
        var place = autocomplete.getPlace();
        if (!place.place_id) {
            window.alert("Please select an option from the dropdown list.");
            return;
        }
        if (mode === 'ORIG') {
            me.originPlaceId = place.place_id;
        } else {
            me.destinationPlaceId = place.place_id;
        }
        me.route();
    });

};

AutocompleteDirectionsHandler.prototype.route = function() {
    if (!this.originPlaceId || !this.destinationPlaceId) {
        return;
    }
    var me = this;

    this.directionsService.route({
        origin: {
            'placeId': this.originPlaceId
        },
        destination: {
            'placeId': this.destinationPlaceId
        },
        travelMode: this.travelMode
    }, function(response, status) {
        if (status === 'OK') {
            me.directionsDisplay.setDirections(response);
        } else {
            window.alert('Directions request failed due to ' + status);
        }
    });
};
function goBack() {
    window.history.back();
}
